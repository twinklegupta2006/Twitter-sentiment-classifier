"""Re-evaluate a saved model against the held-out test set.

Reconstructs the same deterministic splits as scripts/train.py (same
seed and config), loads the saved tokenizer/label encoder/model, and
recomputes test-set metrics. Does not retrain anything.

Usage:
    python scripts/evaluate.py [--config configs/config.yaml]
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from tensorflow.keras.models import load_model

from src.data import load_and_prepare_splits
from src.evaluation import evaluate_model, plot_confusion_matrix
from src.preprocessing import load_label_encoder, load_tokenizer, texts_to_padded
from src.utils import get_logger, load_config, save_json, set_global_seed

logger = get_logger("evaluate")


def main(config_path: str) -> None:
    config = load_config(config_path)
    set_global_seed(config["seed"])

    artifacts_dir = config["artifacts_dir"]
    results_dir = config["results_dir"]

    split = load_and_prepare_splits(config)

    tokenizer = load_tokenizer(os.path.join(artifacts_dir, "tokenizer.json"))
    encoder = load_label_encoder(os.path.join(artifacts_dir, "label_encoder.pkl"))
    model = load_model(os.path.join(artifacts_dir, "sentiment_model.keras"))

    maxlen = config["tokenizer"]["maxlen"]
    X_test = texts_to_padded(tokenizer, split.X_test, maxlen)
    y_test = encoder.transform(split.y_test)
    label_names = list(encoder.classes_)

    eval_result = evaluate_model(model, X_test, y_test, label_names)
    metrics = eval_result["metrics"]

    save_json(metrics, os.path.join(results_dir, "metrics.json"))
    plot_confusion_matrix(eval_result["confusion_matrix"], label_names,
                           os.path.join(results_dir, "confusion_matrix.png"))
    with open(os.path.join(results_dir, "classification_report.txt"), "w", encoding="utf-8") as f:
        f.write(eval_result["classification_report_text"])

    logger.info("Re-evaluated test metrics: %s", metrics)
    logger.info("Classification report:\n%s", eval_result["classification_report_text"])


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/config.yaml")
    args = parser.parse_args()
    main(args.config)
