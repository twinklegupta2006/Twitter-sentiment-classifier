"""Regenerate the small, deterministic PRODUCTION (TF-IDF + Linear SVM)
artifacts that tests/test_api.py and tests/test_predict_svm.py need, for
environments where they aren't already present -- e.g. a fresh CI
checkout, since these binaries are intentionally NOT committed to git
(see .gitignore).

Does NOT touch the LSTM pipeline, does NOT require TensorFlow, and does
NOT require GloVe (only used by the LSTM). Calls the SAME, unmodified
functions scripts/benchmark.py already uses (src.data.load_and_prepare_splits,
src.baselines.fit_tfidf_vectorizer / build_linear_svm / train_sklearn_model)
with the SAME config and SAME seed -- so this produces the identical
artifacts Phase 2's benchmark already validated, not a new or different
model. This is a reproducibility/CI convenience, not a retrain.

Idempotent: does nothing if the artifacts already exist, unless --force
is passed.

Usage:
    python scripts/prepare_ci_artifacts.py [--config configs/config.yaml] [--force]
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from sklearn.preprocessing import LabelEncoder

from src.baselines import (build_linear_svm, fit_tfidf_vectorizer,
                            save_pickle, train_sklearn_model)
from src.data import load_and_prepare_splits
from src.utils import get_logger, load_config

logger = get_logger("prepare_ci_artifacts")

REQUIRED_PATHS = [
    "artifacts/label_encoder.pkl",
    "artifacts/baselines/tfidf_vectorizer.pkl",
    "artifacts/baselines/tfidf_linear_svm.pkl",
]


def already_present() -> bool:
    return all(os.path.exists(p) for p in REQUIRED_PATHS)


def main(config_path: str, force: bool) -> None:
    if already_present() and not force:
        logger.info("Production SVM artifacts already present, skipping (pass --force to regenerate).")
        return

    config = load_config(config_path)
    # Every source of randomness here (train_test_split, LinearSVC) is
    # already explicitly seeded via its own random_state parameter below --
    # deliberately NOT calling the shared set_global_seed() helper, since
    # it imports TensorFlow (for tf.random.set_seed), which this script
    # must not require.
    baselines_cfg = config["baselines"]

    os.makedirs(config["artifacts_dir"], exist_ok=True)
    os.makedirs(baselines_cfg["artifacts_dir"], exist_ok=True)

    split = load_and_prepare_splits(config)

    encoder = LabelEncoder().fit(split.y_train)
    save_pickle(encoder, "artifacts/label_encoder.pkl")

    vectorizer = fit_tfidf_vectorizer(split.X_train, baselines_cfg["tfidf"])
    save_pickle(vectorizer, "artifacts/baselines/tfidf_vectorizer.pkl")

    X_train = vectorizer.transform(split.X_train)
    y_train_enc = encoder.transform(split.y_train)
    model = build_linear_svm(baselines_cfg["linear_svm"], random_state=config["seed"])
    model, training_time = train_sklearn_model(model, X_train, y_train_enc)
    save_pickle(model, "artifacts/baselines/tfidf_linear_svm.pkl")

    logger.info("Regenerated production SVM artifacts in %.1fs: %s", training_time, REQUIRED_PATHS)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/config.yaml")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    main(args.config, args.force)
