"""Run inference using the PRODUCTION model: TF-IDF + Linear SVM.

This is the same model, artifacts, and prediction logic (src/inference_api.py)
used by the Streamlit demo (app.py) -- both share one inference module so
they cannot silently diverge. Loads only:
    artifacts/baselines/tfidf_vectorizer.pkl
    artifacts/baselines/tfidf_linear_svm.pkl
    artifacts/label_encoder.pkl
Does not fit or train anything.

Usage:
    python scripts/predict_svm.py "This product is absolutely amazing!"
    python scripts/predict_svm.py "text one" "text two"
"""
import argparse
import json
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from src.inference_api import (DEFAULT_LABEL_ENCODER_PATH, DEFAULT_MODEL_PATH,
                                DEFAULT_VECTORIZER_PATH,
                                load_production_artifacts, predict_many,
                                validate_texts)
from src.utils import get_logger

logger = get_logger("predict_svm")


def main(
    texts: list,
    vectorizer_path: str = DEFAULT_VECTORIZER_PATH,
    model_path: str = DEFAULT_MODEL_PATH,
    label_encoder_path: str = DEFAULT_LABEL_ENCODER_PATH,
) -> list:
    """Validates input (src.inference_api.validate_texts), loads the production
    artifacts, and returns one result per input text, in order. Deterministic:
    LinearSVC.decision_function has no random component at inference time."""
    try:
        texts = validate_texts(texts)
    except ValueError as exc:
        logger.error("Invalid input: %s", exc)
        raise

    artifacts = load_production_artifacts(vectorizer_path, model_path, label_encoder_path)
    results = predict_many(texts, artifacts)
    print(json.dumps(results, indent=2))
    return results


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("text", nargs="+", help="One or more raw texts to classify")
    parser.add_argument("--vectorizer-path", default=DEFAULT_VECTORIZER_PATH)
    parser.add_argument("--model-path", default=DEFAULT_MODEL_PATH)
    parser.add_argument("--label-encoder-path", default=DEFAULT_LABEL_ENCODER_PATH)
    args = parser.parse_args()
    try:
        main(args.text, args.vectorizer_path, args.model_path, args.label_encoder_path)
    except ValueError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)
