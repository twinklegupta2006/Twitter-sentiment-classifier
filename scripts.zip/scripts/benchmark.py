"""Phase 2: benchmark TF-IDF+LogisticRegression, TF-IDF+LinearSVM and the
existing LSTM+GloVe model on the identical Phase 1 test split.

All three models reuse the exact same deduplicated, leakage-verified
train/val/test split produced by src.data.load_and_prepare_splits (same
config, same seed) — no model gets its own split. The LSTM is NOT
retrained here: it reuses the Phase 1 artifacts (artifacts/tokenizer.json,
artifacts/label_encoder.pkl, artifacts/sentiment_model.keras) and Phase 1's
recorded training time, since retraining would not change the comparison
and would cost ~20 minutes for no benefit.

Usage:
    python scripts/benchmark.py [--config configs/config.yaml]
"""
import argparse
import json
import os
import sys
import time

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from tensorflow.keras.models import load_model

from src.baselines import (build_linear_svm, build_logistic_regression,
                            count_sklearn_params, fit_tfidf_vectorizer,
                            save_pickle, train_sklearn_model)
from src.benchmark import (artifact_size_bytes, build_comparison_table,
                            measure_inference_latency, plot_comparison)
from src.data import load_and_prepare_splits
from src.evaluation import compute_classification_metrics, plot_confusion_matrix
from src.preprocessing import load_label_encoder, load_tokenizer, texts_to_padded
from src.utils import get_logger, load_config, save_json, set_global_seed

logger = get_logger("benchmark")


def save_model_report(model_name, eval_result, label_names, results_dir):
    save_json(eval_result["classification_report_dict"],
              os.path.join(results_dir, f"{model_name}_classification_report.json"))
    with open(os.path.join(results_dir, f"{model_name}_classification_report.txt"), "w", encoding="utf-8") as f:
        f.write(eval_result["classification_report_text"])
    plot_confusion_matrix(eval_result["confusion_matrix"], label_names,
                           os.path.join(results_dir, f"{model_name}_confusion_matrix.png"))


def run_tfidf_baseline(model_name, build_fn, model_cfg, X_train_tfidf, y_train_enc,
                        X_test_tfidf, y_test_enc, label_names, vectorizer_fit_time,
                        vectorizer_size_bytes, artifacts_dir, results_dir):
    logger.info("Training %s ...", model_name)
    model = build_fn(model_cfg)
    model, classifier_fit_time = train_sklearn_model(model, X_train_tfidf, y_train_enc)
    training_time_seconds = vectorizer_fit_time + classifier_fit_time

    latency = measure_inference_latency(model.predict, X_test_tfidf)
    y_pred = model.predict(X_test_tfidf)

    eval_result = compute_classification_metrics(
        y_test_enc, y_pred, label_names,
        extra_metrics={
            "training_time_seconds": round(training_time_seconds, 4),
            "per_sample_latency_ms": latency["per_sample_latency_ms"],
            "num_parameters": count_sklearn_params(model),
        },
    )
    save_model_report(model_name, eval_result, label_names, results_dir)

    model_path = os.path.join(artifacts_dir, f"{model_name}.pkl")
    save_pickle(model, model_path)
    artifact_bytes = vectorizer_size_bytes + os.path.getsize(model_path)
    eval_result["metrics"]["artifact_size_bytes"] = artifact_bytes
    eval_result["metrics"]["artifact_size_mb"] = round(artifact_bytes / (1024 * 1024), 3)

    logger.info("%s test metrics: %s", model_name, eval_result["metrics"])
    return {"model_name": model_name, **eval_result["metrics"]}


def run_lstm_benchmark(split, label_names, config, results_dir):
    model_name = "lstm_glove"
    artifacts_dir = config["artifacts_dir"]
    logger.info("Loading existing LSTM+GloVe artifacts from %s (not retraining)", artifacts_dir)

    tokenizer = load_tokenizer(os.path.join(artifacts_dir, "tokenizer.json"))
    encoder = load_label_encoder(os.path.join(artifacts_dir, "label_encoder.pkl"))
    model = load_model(os.path.join(artifacts_dir, "sentiment_model.keras"))

    maxlen = config["tokenizer"]["maxlen"]
    X_test = texts_to_padded(tokenizer, split.X_test, maxlen)
    y_test_enc = encoder.transform(split.y_test)

    with open(os.path.join(artifacts_dir, "metrics.json"), "r", encoding="utf-8") as f:
        phase1_metrics = json.load(f)
    training_time_seconds = phase1_metrics["training_time_seconds"]

    def predict_fn(X):
        return model.predict(X, verbose=0)

    latency = measure_inference_latency(predict_fn, X_test)
    y_pred_probs = model.predict(X_test, verbose=0)
    y_pred = y_pred_probs.argmax(axis=1)

    eval_result = compute_classification_metrics(
        y_test_enc, y_pred, label_names,
        extra_metrics={
            "training_time_seconds": training_time_seconds,
            "training_time_note": "reused from Phase 1 (not retrained)",
            "per_sample_latency_ms": latency["per_sample_latency_ms"],
            "num_parameters": int(model.count_params()),
        },
    )
    save_model_report(model_name, eval_result, label_names, results_dir)

    artifact_bytes = artifact_size_bytes([
        os.path.join(artifacts_dir, "sentiment_model.keras"),
        os.path.join(artifacts_dir, "tokenizer.json"),
        os.path.join(artifacts_dir, "label_encoder.pkl"),
    ])
    eval_result["metrics"]["artifact_size_bytes"] = artifact_bytes
    eval_result["metrics"]["artifact_size_mb"] = round(artifact_bytes / (1024 * 1024), 3)

    logger.info("%s test metrics: %s", model_name, eval_result["metrics"])
    return {"model_name": model_name, **eval_result["metrics"]}


def main(config_path: str) -> None:
    config = load_config(config_path)
    set_global_seed(config["seed"])

    baselines_cfg = config["baselines"]
    artifacts_dir = baselines_cfg["artifacts_dir"]
    results_dir = baselines_cfg["results_dir"]
    os.makedirs(artifacts_dir, exist_ok=True)
    os.makedirs(results_dir, exist_ok=True)

    # 1. Reuse the exact Phase 1 split (same config/seed) -- verified leakage-free.
    split = load_and_prepare_splits(config)
    save_json(split.report, os.path.join(results_dir, "data_split_report.json"))

    # 2. Reuse the Phase 1 label encoder so class ordering is identical across all models.
    encoder = load_label_encoder(os.path.join(config["artifacts_dir"], "label_encoder.pkl"))
    label_names = list(encoder.classes_)
    y_train_enc = encoder.transform(split.y_train)
    y_test_enc = encoder.transform(split.y_test)

    # 3. Fit TF-IDF on TRAINING TEXT ONLY. Shared by both baseline classifiers.
    start = time.time()
    vectorizer = fit_tfidf_vectorizer(split.X_train, baselines_cfg["tfidf"])
    vectorizer_fit_time = time.time() - start

    X_train_tfidf = vectorizer.transform(split.X_train)
    X_test_tfidf = vectorizer.transform(split.X_test)

    vectorizer_path = os.path.join(artifacts_dir, "tfidf_vectorizer.pkl")
    save_pickle(vectorizer, vectorizer_path)
    vectorizer_size_bytes = os.path.getsize(vectorizer_path)

    results = []

    # 4. TF-IDF + Logistic Regression.
    results.append(run_tfidf_baseline(
        "tfidf_logistic_regression", build_logistic_regression, baselines_cfg["logistic_regression"],
        X_train_tfidf, y_train_enc, X_test_tfidf, y_test_enc, label_names,
        vectorizer_fit_time, vectorizer_size_bytes, artifacts_dir, results_dir,
    ))

    # 5. TF-IDF + Linear SVM.
    results.append(run_tfidf_baseline(
        "tfidf_linear_svm", build_linear_svm, baselines_cfg["linear_svm"],
        X_train_tfidf, y_train_enc, X_test_tfidf, y_test_enc, label_names,
        vectorizer_fit_time, vectorizer_size_bytes, artifacts_dir, results_dir,
    ))

    # 6. Existing LSTM + GloVe (reused, not retrained).
    results.append(run_lstm_benchmark(split, label_names, config, results_dir))

    # 7. Comparison table + plot + full experiment record.
    df = build_comparison_table(results, os.path.join(results_dir, "benchmark_results.csv"))
    plot_comparison(df, os.path.join(results_dir, "comparison_plot.png"))

    save_json({
        "config": baselines_cfg,
        "split_report": split.report,
        "results": results,
    }, os.path.join(results_dir, "experiment_config_and_metrics.json"))

    logger.info("Benchmark complete. Results written to %s", results_dir)
    for row in results:
        logger.info("%s", row)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/config.yaml")
    args = parser.parse_args()
    main(args.config)
