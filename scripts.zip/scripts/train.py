"""Train the baseline LSTM + GloVe sentiment classifier end-to-end.

Usage:
    python scripts/train.py [--config configs/config.yaml]
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from src.data import load_and_prepare_splits
from src.evaluation import evaluate_model, plot_confusion_matrix, plot_training_history
from src.model import build_lstm_model
from src.preprocessing import (build_embedding_matrix, fit_label_encoder,
                                fit_tokenizer, load_glove_embeddings,
                                save_label_encoder, save_tokenizer,
                                texts_to_padded)
from src.training import train_model
from src.utils import get_logger, load_config, save_json, set_global_seed

logger = get_logger("train")


def main(config_path: str) -> None:
    config = load_config(config_path)
    set_global_seed(config["seed"])

    artifacts_dir = config["artifacts_dir"]
    results_dir = config["results_dir"]
    os.makedirs(artifacts_dir, exist_ok=True)
    os.makedirs(results_dir, exist_ok=True)

    # 1. Data: load, clean, dedupe, split, verify no leakage.
    split = load_and_prepare_splits(config)
    save_json(split.report, os.path.join(results_dir, "data_split_report.json"))
    logger.info("Data split report saved.")

    # 2. Preprocessing: tokenizer + label encoder fit on TRAIN ONLY.
    tok_cfg = config["tokenizer"]
    tokenizer = fit_tokenizer(split.X_train, tok_cfg["num_words"], tok_cfg["oov_token"])
    encoder = fit_label_encoder(split.y_train)

    X_train = texts_to_padded(tokenizer, split.X_train, tok_cfg["maxlen"])
    X_val = texts_to_padded(tokenizer, split.X_val, tok_cfg["maxlen"])
    X_test = texts_to_padded(tokenizer, split.X_test, tok_cfg["maxlen"])

    y_train = encoder.transform(split.y_train)
    y_val = encoder.transform(split.y_val)
    y_test = encoder.transform(split.y_test)

    save_tokenizer(tokenizer, os.path.join(artifacts_dir, "tokenizer.json"))
    save_label_encoder(encoder, os.path.join(artifacts_dir, "label_encoder.pkl"))
    logger.info("Tokenizer and label encoder saved.")

    # 3. GloVe embedding matrix.
    emb_cfg = config["embedding"]
    embedding_index = load_glove_embeddings(emb_cfg["glove_path"])
    vocab_size = min(tok_cfg["num_words"], len(tokenizer.word_index) + 1)
    embedding_matrix = build_embedding_matrix(
        tokenizer, embedding_index, tok_cfg["num_words"], emb_cfg["embedding_dim"]
    )

    # 4. Build model (unchanged baseline architecture).
    model_cfg = config["model"]
    model = build_lstm_model(
        vocab_size=vocab_size,
        embedding_dim=emb_cfg["embedding_dim"],
        embedding_matrix=embedding_matrix,
        maxlen=tok_cfg["maxlen"],
        lstm_units=model_cfg["lstm_units"],
        lstm_dropout=model_cfg["lstm_dropout"],
        dense_dropout=model_cfg["dense_dropout"],
        num_classes=len(config["data"]["classes"]),
    )
    model.summary(print_fn=logger.info)
    trainable_params = int(sum(w.numpy().size for w in model.trainable_weights))

    # 5. Train.
    history, training_time_seconds = train_model(
        model, X_train, y_train, X_val, y_val, config["training"]
    )
    save_json(history.history, os.path.join(artifacts_dir, "training_history.json"))
    plot_training_history(history.history, os.path.join(results_dir, "training_history.png"))

    # 6. Save model in native Keras format.
    model_path = os.path.join(artifacts_dir, "sentiment_model.keras")
    model.save(model_path)
    logger.info("Model saved to %s", model_path)

    # 7. Evaluate ONLY on the held-out test set.
    label_names = list(encoder.classes_)
    eval_result = evaluate_model(model, X_test, y_test, label_names)

    metrics = eval_result["metrics"]
    metrics["trainable_params"] = trainable_params
    metrics["training_time_seconds"] = round(training_time_seconds, 2)

    save_json(metrics, os.path.join(artifacts_dir, "metrics.json"))
    save_json(eval_result["classification_report_dict"],
              os.path.join(artifacts_dir, "classification_report.json"))
    plot_confusion_matrix(eval_result["confusion_matrix"], label_names,
                           os.path.join(artifacts_dir, "confusion_matrix.png"))

    # results/ mirrors the human-readable evaluation artifacts.
    save_json(metrics, os.path.join(results_dir, "metrics.json"))
    plot_confusion_matrix(eval_result["confusion_matrix"], label_names,
                           os.path.join(results_dir, "confusion_matrix.png"))
    with open(os.path.join(results_dir, "classification_report.txt"), "w", encoding="utf-8") as f:
        f.write(eval_result["classification_report_text"])

    logger.info("Final test metrics: %s", metrics)
    logger.info("Classification report:\n%s", eval_result["classification_report_text"])


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/config.yaml")
    args = parser.parse_args()
    main(args.config)
