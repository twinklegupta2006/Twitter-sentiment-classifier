"""Core prediction logic for the production TF-IDF + Linear SVM model.

Serves ONLY the existing, already-selected production artifacts:
  - artifacts/baselines/tfidf_vectorizer.pkl
  - artifacts/baselines/tfidf_linear_svm.pkl
  - artifacts/label_encoder.pkl

No retraining, no fitting, no changed preprocessing happens here -- this
module only loads what was already produced and calls
.transform()/.predict()/.decision_function() on it.
Used by both app.py (Streamlit) and scripts/predict_svm.py (CLI).

Deliberately does NOT import src.preprocessing (which pulls in TensorFlow
for the LSTM baseline) -- the label encoder is a plain pickled
scikit-learn object, loaded here via the same src.baselines.load_pickle
used for the vectorizer and model, so this stays free of the TensorFlow
dependency entirely.
"""
from dataclasses import dataclass

import numpy as np

from src.baselines import load_pickle

DEFAULT_VECTORIZER_PATH = "artifacts/baselines/tfidf_vectorizer.pkl"
DEFAULT_MODEL_PATH = "artifacts/baselines/tfidf_linear_svm.pkl"
DEFAULT_LABEL_ENCODER_PATH = "artifacts/label_encoder.pkl"

# Shared input-validation limits -- used by scripts/predict_svm.py so
# validation logic isn't duplicated there.
MAX_TEXT_LENGTH = 2000   # characters per text
MAX_BATCH_SIZE = 64      # texts per batch request


def validate_text(text: str) -> str:
    """Raises ValueError with a clear message on empty/whitespace-only or
    excessively long text. Returns the text unchanged if valid."""
    if text is None or not text.strip():
        raise ValueError("text must not be empty or whitespace-only")
    if len(text) > MAX_TEXT_LENGTH:
        raise ValueError(f"text exceeds maximum length of {MAX_TEXT_LENGTH} characters (got {len(text)})")
    return text


def validate_texts(texts: list) -> list:
    """Validates a batch: non-empty list, within MAX_BATCH_SIZE, and every
    element individually valid per validate_text."""
    if not texts:
        raise ValueError("texts must not be empty")
    if len(texts) > MAX_BATCH_SIZE:
        raise ValueError(f"batch size exceeds maximum of {MAX_BATCH_SIZE} (got {len(texts)})")
    return [validate_text(t) for t in texts]


@dataclass
class ProductionArtifacts:
    vectorizer: object
    model: object
    encoder: object
    label_names: list


def load_production_artifacts(
    vectorizer_path: str = DEFAULT_VECTORIZER_PATH,
    model_path: str = DEFAULT_MODEL_PATH,
    label_encoder_path: str = DEFAULT_LABEL_ENCODER_PATH,
) -> ProductionArtifacts:
    """Load-only. Raises (FileNotFoundError / pickle errors) if any artifact
    is missing or unreadable -- callers decide how to handle that (the API
    catches this and reports a degraded /health instead of crashing)."""
    vectorizer = load_pickle(vectorizer_path)
    model = load_pickle(model_path)
    encoder = load_pickle(label_encoder_path)
    return ProductionArtifacts(
        vectorizer=vectorizer, model=model, encoder=encoder,
        label_names=list(encoder.classes_),
    )


def predict_one(text: str, artifacts: ProductionArtifacts) -> dict:
    return predict_many([text], artifacts)[0]


def predict_many(texts: list, artifacts: ProductionArtifacts) -> list:
    """Runs the exact training-time preprocessing (whatever the fitted
    vectorizer's tokenizer/preprocessor already is -- unchanged from Phase 2)
    via .transform(), then the production LinearSVC's .predict() and
    .decision_function(). Does not fit or train anything.

    LinearSVC has no native predict_proba -- the returned scores are raw
    decision-function values (NOT probabilities), plus a margin-based
    confidence proxy (top-1 minus top-2 decision score), consistent with
    the terminology established in the Phase 3 error analysis.
    """
    X = artifacts.vectorizer.transform(texts)
    pred_enc = artifacts.model.predict(X)
    decision = artifacts.model.decision_function(X)
    pred_labels = artifacts.encoder.inverse_transform(pred_enc)

    results = []
    for text, label, scores in zip(texts, pred_labels, decision):
        label = str(label)
        pred_idx = artifacts.label_names.index(label)
        sorted_scores = np.sort(scores)[::-1]
        margin = float(sorted_scores[0] - sorted_scores[1])
        results.append({
            "predicted_label": label,
            "decision_scores": {name: float(s) for name, s in zip(artifacts.label_names, scores)},
            "decision_score_predicted_class": float(scores[pred_idx]),
            "confidence_proxy": margin,
            "text_length": len(text),
        })
    return results
