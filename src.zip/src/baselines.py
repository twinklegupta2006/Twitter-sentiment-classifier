"""Traditional NLP baselines: TF-IDF + Logistic Regression / Linear SVM.

The TF-IDF vectorizer is fit on the training split only and shared by
both classifiers (same features, same fair comparison). No hyperparameter
search is performed — each model uses one small, documented configuration.
"""
import pickle
import time

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.svm import LinearSVC

from src.utils import get_logger

logger = get_logger(__name__)


def fit_tfidf_vectorizer(train_texts: list, cfg: dict) -> TfidfVectorizer:
    vectorizer = TfidfVectorizer(
        ngram_range=tuple(cfg["ngram_range"]),
        min_df=cfg["min_df"],
        max_features=cfg["max_features"],
    )
    vectorizer.fit(train_texts)
    logger.info(
        "TF-IDF fit on %d training texts -> vocabulary size %d (ngram_range=%s, min_df=%s, max_features=%s)",
        len(train_texts), len(vectorizer.vocabulary_), cfg["ngram_range"], cfg["min_df"], cfg["max_features"],
    )
    return vectorizer


def build_logistic_regression(cfg: dict) -> LogisticRegression:
    return LogisticRegression(
        C=cfg["C"],
        max_iter=cfg["max_iter"],
        class_weight=cfg["class_weight"],
    )


def build_linear_svm(cfg: dict, random_state: int = None) -> LinearSVC:
    return LinearSVC(
        C=cfg["C"],
        max_iter=cfg["max_iter"],
        class_weight=cfg["class_weight"],
        random_state=random_state,
    )


def train_sklearn_model(model, X_train, y_train):
    start = time.time()
    model.fit(X_train, y_train)
    training_time_seconds = time.time() - start
    return model, training_time_seconds


def count_sklearn_params(model) -> int:
    """Number of learned scalar parameters (coefficients + intercepts)."""
    return int(model.coef_.size + model.intercept_.size)


def save_pickle(obj, path: str) -> None:
    with open(path, "wb") as f:
        pickle.dump(obj, f)


def load_pickle(path: str):
    with open(path, "rb") as f:
        return pickle.load(f)
