"""Shared benchmarking helpers: latency measurement, artifact sizing,
comparison table/plot construction. Used by scripts/benchmark.py to
compare TF-IDF+LogReg, TF-IDF+LinearSVM and the LSTM+GloVe baseline on
the identical Phase 1 test split.
"""
import os
import time

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from src.utils import get_logger

logger = get_logger(__name__)


def measure_inference_latency(predict_fn, X_test, n_repeats: int = 3) -> dict:
    """Runs predict_fn(X_test) n_repeats times and reports per-sample latency.

    A small, fixed number of repeats (not a search) to smooth out timing
    noise; all repeats use the identical, already-transformed test inputs.
    """
    n_samples = X_test.shape[0] if hasattr(X_test, "shape") else len(X_test)
    times = []
    for _ in range(n_repeats):
        start = time.perf_counter()
        predict_fn(X_test)
        times.append(time.perf_counter() - start)

    total_seconds = min(times)  # best-of-N, standard practice for latency measurement
    return {
        "total_inference_seconds": total_seconds,
        "per_sample_latency_ms": (total_seconds / n_samples) * 1000,
        "n_test_samples": n_samples,
    }


def artifact_size_bytes(paths: list) -> int:
    total = 0
    for p in paths:
        if os.path.exists(p):
            total += os.path.getsize(p)
    return total


def build_comparison_table(results: list, out_csv: str) -> pd.DataFrame:
    """results: list of flat dicts, one row per model."""
    df = pd.DataFrame(results)
    os.makedirs(os.path.dirname(out_csv), exist_ok=True)
    df.to_csv(out_csv, index=False)
    logger.info("Saved comparison table to %s", out_csv)
    return df


def plot_comparison(df: pd.DataFrame, out_path: str) -> None:
    metrics_to_plot = ["test_accuracy", "macro_f1", "weighted_f1"]
    fig, ax = plt.subplots(figsize=(9, 5))

    x = np.arange(len(df))
    width = 0.25
    for i, metric in enumerate(metrics_to_plot):
        ax.bar(x + i * width, df[metric], width, label=metric)

    ax.set_xticks(x + width)
    ax.set_xticklabels(df["model_name"], rotation=15, ha="right")
    ax.set_ylim(0, 1.0)
    ax.set_ylabel("Score")
    ax.set_title("Model Comparison on Held-Out Test Set")
    ax.legend()
    ax.grid(True, axis="y", alpha=0.3)

    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    logger.info("Saved comparison plot to %s", out_path)
