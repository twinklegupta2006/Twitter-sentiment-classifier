"""Data loading, cleaning, deduplication and leakage-free splitting.

Pipeline order (deliberate, to avoid the leakage found in the original
notebook): load -> inspect -> drop NA -> filter classes -> record
pre-dedup distribution -> drop duplicate texts -> record post-dedup
distribution -> stratified split -> verify zero overlap.
"""
from dataclasses import dataclass, field

import pandas as pd
from sklearn.model_selection import train_test_split

from src.utils import get_logger

logger = get_logger(__name__)


@dataclass
class SplitData:
    X_train: list
    y_train: list
    X_val: list
    y_val: list
    X_test: list
    y_test: list
    report: dict = field(default_factory=dict)


def load_raw_data(csv_path: str, columns: list) -> pd.DataFrame:
    df = pd.read_csv(csv_path, header=None)
    df.columns = columns
    return df


def clean_and_filter(df: pd.DataFrame, classes: list) -> tuple[pd.DataFrame, dict]:
    """Drop missing rows and keep only the configured classes.

    Returns the cleaned dataframe and a stats dict covering steps that
    happen before deduplication.
    """
    original_rows = len(df)
    missing_rows = int(df.isna().any(axis=1).sum())

    df_clean = df.dropna(subset=["text", "sentiment"]).copy()
    df_clean["text"] = df_clean["text"].astype(str)

    df_filtered = df_clean[df_clean["sentiment"].isin(classes)].copy()

    class_dist_before_dedup = (
        df_filtered["sentiment"].value_counts().to_dict()
    )

    stats = {
        "original_rows": original_rows,
        "missing_rows_dropped": missing_rows,
        "rows_after_class_filter": len(df_filtered),
        "class_distribution_before_dedup": class_dist_before_dedup,
    }
    return df_filtered, stats


def deduplicate_texts(df: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    """Drop rows with an exact-duplicate `text`, keeping the first occurrence.

    This must run BEFORE splitting: once every text is unique, no split
    (train/val/test) can share a text with another split.
    """
    rows_before = len(df)
    duplicate_texts = int(df["text"].duplicated().sum())

    df_dedup = df.drop_duplicates(subset=["text"], keep="first").copy()

    rows_removed = rows_before - len(df_dedup)
    class_dist_after_dedup = df_dedup["sentiment"].value_counts().to_dict()

    stats = {
        "duplicate_texts_found": duplicate_texts,
        "rows_removed_in_dedup": rows_removed,
        "rows_after_dedup": len(df_dedup),
        "class_distribution_after_dedup": class_dist_after_dedup,
    }
    return df_dedup, stats


def split_data(
    df: pd.DataFrame,
    test_size: float,
    val_size: float,
    random_state: int,
    stratify: bool = True,
) -> SplitData:
    """Stratified 70/15/15 (by default) train/val/test split.

    Because `df` has already been deduplicated on `text`, every text is
    unique in the full dataset, so a disjoint row-level split guarantees
    zero text overlap between splits. This is verified explicitly by
    `verify_no_overlap` rather than assumed.
    """
    texts = df["text"].values
    labels = df["sentiment"].values

    strat = labels if stratify else None
    X_train, X_temp, y_train, y_temp = train_test_split(
        texts, labels, test_size=(test_size + val_size),
        random_state=random_state, stratify=strat,
    )

    relative_test_size = test_size / (test_size + val_size)
    strat_temp = y_temp if stratify else None
    X_val, X_test, y_val, y_test = train_test_split(
        X_temp, y_temp, test_size=relative_test_size,
        random_state=random_state, stratify=strat_temp,
    )

    return SplitData(
        X_train=list(X_train), y_train=list(y_train),
        X_val=list(X_val), y_val=list(y_val),
        X_test=list(X_test), y_test=list(y_test),
    )


def verify_no_overlap(split: SplitData) -> dict:
    train_set = set(split.X_train)
    val_set = set(split.X_val)
    test_set = set(split.X_test)

    overlap = {
        "train_val_overlap": len(train_set & val_set),
        "train_test_overlap": len(train_set & test_set),
        "val_test_overlap": len(val_set & test_set),
    }
    if any(v > 0 for v in overlap.values()):
        raise ValueError(f"Split overlap detected, leakage present: {overlap}")
    return overlap


def build_split_report(pre_dedup_stats: dict, dedup_stats: dict, split: SplitData, overlap: dict) -> dict:
    report = {
        **pre_dedup_stats,
        **dedup_stats,
        "train_rows": len(split.X_train),
        "val_rows": len(split.X_val),
        "test_rows": len(split.X_test),
        "train_unique_texts": len(set(split.X_train)),
        "val_unique_texts": len(set(split.X_val)),
        "test_unique_texts": len(set(split.X_test)),
        "overlap": overlap,
    }
    return report


def load_and_prepare_splits(config: dict) -> SplitData:
    """End-to-end, deterministic data-prep entrypoint used by both
    scripts/train.py and scripts/evaluate.py so both reconstruct the
    exact same splits from the same seeded configuration."""
    data_cfg = config["data"]
    split_cfg = config["split"]

    df = load_raw_data(data_cfg["csv_path"], data_cfg["raw_columns"])
    logger.info("Loaded raw data: %d rows", len(df))

    df_filtered, pre_dedup_stats = clean_and_filter(df, data_cfg["classes"])
    logger.info(
        "After NA drop + class filter: %d rows (dropped %d missing rows)",
        pre_dedup_stats["rows_after_class_filter"],
        pre_dedup_stats["missing_rows_dropped"],
    )

    df_dedup, dedup_stats = deduplicate_texts(df_filtered)
    logger.info(
        "After deduplication: %d rows (removed %d duplicate texts)",
        dedup_stats["rows_after_dedup"],
        dedup_stats["rows_removed_in_dedup"],
    )

    split = split_data(
        df_dedup,
        test_size=split_cfg["test_size"],
        val_size=split_cfg["val_size"],
        random_state=split_cfg["random_state"],
        stratify=split_cfg.get("stratify", True),
    )

    overlap = verify_no_overlap(split)
    logger.info("Split overlap check passed: %s", overlap)

    split.report = build_split_report(pre_dedup_stats, dedup_stats, split, overlap)
    return split
