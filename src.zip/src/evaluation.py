"""Evaluation metrics, confusion matrix and plotting utilities.

Evaluation must only ever be run against the held-out test set.
"""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from sklearn.metrics import (classification_report, confusion_matrix,
                              precision_recall_fscore_support)


def compute_classification_metrics(y_test, y_pred, label_names: list, extra_metrics: dict = None) -> dict:
    """Shared metrics computation used by every model type (Keras or sklearn),
    so accuracy/precision/recall/F1/confusion-matrix are always derived the
    same way from actual test-set predictions."""
    macro_p, macro_r, macro_f1, _ = precision_recall_fscore_support(
        y_test, y_pred, average="macro", zero_division=0
    )
    _, _, weighted_f1, _ = precision_recall_fscore_support(
        y_test, y_pred, average="weighted", zero_division=0
    )
    accuracy = float(np.mean(np.asarray(y_test) == np.asarray(y_pred)))

    report_dict = classification_report(
        y_test, y_pred, target_names=label_names, output_dict=True, zero_division=0
    )
    report_text = classification_report(
        y_test, y_pred, target_names=label_names, zero_division=0
    )
    cm = confusion_matrix(y_test, y_pred)

    metrics = {
        "test_accuracy": accuracy,
        "macro_precision": float(macro_p),
        "macro_recall": float(macro_r),
        "macro_f1": float(macro_f1),
        "weighted_f1": float(weighted_f1),
    }
    if extra_metrics:
        metrics.update(extra_metrics)

    return {
        "metrics": metrics,
        "classification_report_dict": report_dict,
        "classification_report_text": report_text,
        "confusion_matrix": cm,
        "y_pred": y_pred,
    }


def evaluate_model(model, X_test: np.ndarray, y_test: np.ndarray, label_names: list) -> dict:
    loss, _ = model.evaluate(X_test, y_test, verbose=0)
    y_pred_probs = model.predict(X_test, verbose=0)
    y_pred = np.argmax(y_pred_probs, axis=1)

    result = compute_classification_metrics(y_test, y_pred, label_names, extra_metrics={"test_loss": float(loss)})
    return result


def plot_confusion_matrix(cm: np.ndarray, label_names: list, out_path: str) -> None:
    fig, ax = plt.subplots(figsize=(6, 5))
    im = ax.imshow(cm, cmap="Blues")
    ax.set_xticks(range(len(label_names)))
    ax.set_yticks(range(len(label_names)))
    ax.set_xticklabels(label_names)
    ax.set_yticklabels(label_names)
    ax.set_xlabel("Predicted")
    ax.set_ylabel("True")
    ax.set_title("Confusion Matrix (Test Set)")
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            ax.text(j, i, str(cm[i, j]), ha="center", va="center",
                     color="white" if cm[i, j] > cm.max() / 2 else "black")
    fig.colorbar(im, ax=ax)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)


def plot_training_history(history_dict: dict, out_path: str) -> None:
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))

    axes[0].plot(history_dict["accuracy"], label="Train Accuracy")
    axes[0].plot(history_dict["val_accuracy"], label="Val Accuracy")
    axes[0].set_title("Model Accuracy")
    axes[0].set_xlabel("Epoch")
    axes[0].set_ylabel("Accuracy")
    axes[0].legend()
    axes[0].grid(True)

    axes[1].plot(history_dict["loss"], label="Train Loss")
    axes[1].plot(history_dict["val_loss"], label="Val Loss")
    axes[1].set_title("Model Loss")
    axes[1].set_xlabel("Epoch")
    axes[1].set_ylabel("Loss")
    axes[1].legend()
    axes[1].grid(True)

    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
