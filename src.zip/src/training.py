"""Class weighting, callbacks and the training loop wrapper."""
import time

import numpy as np
from sklearn.utils.class_weight import compute_class_weight
from tensorflow.keras.callbacks import EarlyStopping

from src.utils import get_logger

logger = get_logger(__name__)


def compute_class_weights(y_train: np.ndarray) -> dict:
    classes = np.unique(y_train)
    weights = compute_class_weight("balanced", classes=classes, y=y_train)
    return dict(enumerate(weights))


def train_model(model, X_train, y_train, X_val, y_val, training_cfg: dict):
    class_weight_dict = compute_class_weights(y_train)
    logger.info("Class weights: %s", class_weight_dict)

    early_stop = EarlyStopping(
        monitor=training_cfg["early_stopping_monitor"],
        patience=training_cfg["early_stopping_patience"],
        restore_best_weights=True,
    )

    start = time.time()
    history = model.fit(
        X_train, y_train,
        validation_data=(X_val, y_val),
        epochs=training_cfg["epochs"],
        batch_size=training_cfg["batch_size"],
        callbacks=[early_stop],
        class_weight=class_weight_dict,
    )
    training_time_seconds = time.time() - start
    logger.info("Training completed in %.1f seconds", training_time_seconds)

    return history, training_time_seconds
