"""Tokenization, padding, label encoding and GloVe embedding matrix construction.

Tokenizer and LabelEncoder are always fit on the training split only.
"""
import pickle

import numpy as np
from sklearn.preprocessing import LabelEncoder
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.preprocessing.text import Tokenizer, tokenizer_from_json

from src.utils import get_logger

logger = get_logger(__name__)


def fit_tokenizer(train_texts: list, num_words: int, oov_token: str) -> Tokenizer:
    tokenizer = Tokenizer(num_words=num_words, oov_token=oov_token, lower=True)
    tokenizer.fit_on_texts(train_texts)
    return tokenizer


def texts_to_padded(tokenizer: Tokenizer, texts: list, maxlen: int) -> np.ndarray:
    sequences = tokenizer.texts_to_sequences(texts)
    return pad_sequences(sequences, maxlen=maxlen, padding="post")


def fit_label_encoder(train_labels: list) -> LabelEncoder:
    encoder = LabelEncoder()
    encoder.fit(train_labels)
    return encoder


def load_glove_embeddings(glove_path: str) -> dict:
    embedding_index = {}
    with open(glove_path, encoding="utf-8") as f:
        for line in f:
            values = line.rstrip().split(" ")
            word = values[0]
            coefs = np.asarray(values[1:], dtype="float32")
            embedding_index[word] = coefs
    logger.info("Loaded %d word vectors from GloVe", len(embedding_index))
    return embedding_index


def build_embedding_matrix(tokenizer: Tokenizer, embedding_index: dict, num_words: int, embedding_dim: int) -> np.ndarray:
    vocab_size = min(num_words, len(tokenizer.word_index) + 1)
    embedding_matrix = np.zeros((vocab_size, embedding_dim))
    hits = 0
    for word, i in tokenizer.word_index.items():
        if i >= vocab_size:
            continue
        vector = embedding_index.get(word)
        if vector is not None:
            embedding_matrix[i] = vector
            hits += 1
    logger.info(
        "Embedding matrix coverage: %d/%d tokens found in GloVe (%.2f%%)",
        hits, vocab_size, 100 * hits / vocab_size,
    )
    return embedding_matrix


def save_tokenizer(tokenizer: Tokenizer, path: str) -> None:
    with open(path, "w", encoding="utf-8") as f:
        f.write(tokenizer.to_json())


def load_tokenizer(path: str) -> Tokenizer:
    with open(path, "r", encoding="utf-8") as f:
        return tokenizer_from_json(f.read())


def save_label_encoder(encoder: LabelEncoder, path: str) -> None:
    with open(path, "wb") as f:
        pickle.dump(encoder, f)


def load_label_encoder(path: str) -> LabelEncoder:
    with open(path, "rb") as f:
        return pickle.load(f)
