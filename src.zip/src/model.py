"""Baseline architecture: Embedding(GloVe) -> LSTM -> Dropout -> Dense(softmax).

Kept intentionally unchanged from the original notebook's architecture.
"""
import numpy as np
from tensorflow.keras.layers import Dense, Dropout, Embedding, LSTM
from tensorflow.keras.models import Sequential


def build_lstm_model(
    vocab_size: int,
    embedding_dim: int,
    embedding_matrix: np.ndarray,
    maxlen: int,
    lstm_units: int,
    lstm_dropout: float,
    dense_dropout: float,
    num_classes: int,
) -> Sequential:
    model = Sequential([
        Embedding(
            input_dim=vocab_size,
            output_dim=embedding_dim,
            weights=[embedding_matrix],
            trainable=True,
        ),
        LSTM(lstm_units, dropout=lstm_dropout),
        Dropout(dense_dropout),
        Dense(num_classes, activation="softmax"),
    ])
    model.compile(
        loss="sparse_categorical_crossentropy",
        optimizer="adam",
        metrics=["accuracy"],
    )
    model.build(input_shape=(None, maxlen))
    return model
